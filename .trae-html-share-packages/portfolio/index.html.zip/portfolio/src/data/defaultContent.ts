import type { SiteContent } from '../types';

export const defaultContent: SiteContent = {
  "site": {
    "name": "Portfolio",
    "logoText": "wangying",
    "footerText": "© 2026 · 用设计解决问题"
  },
  "hero": {
    "eyebrow": "UI / UX DESIGNER · INTERACTION",
    "title": "你好，我是王颖。\n一名专注体验的 UI 设计师。",
    "subtitle": "聚焦产品界面、交互设计与设计系统，用清晰的层级、简约的视觉和细腻的微交互，把复杂的问题变简单。",
    "ctaPrimary": "查看作品",
    "ctaSecondary": "关于我",
    "slides": [
      {
        "id": "s1",
        "image": "https://pictures-for-portfolio-1465022720.cos.ap-shanghai.myqcloud.com/4.png",
        "title": "Mood Garden ",
        "subtitle": "情绪花园",
        "link": "/ui/cases/case-1/index.html"
      },
      {
        "id": "s2",
        "image": "https://pictures-for-portfolio-1465022720.cos.ap-shanghai.myqcloud.com/3.png",
        "title": "WanderMap ",
        "subtitle": "把城市走成一本私藏地图",
        "link": "/ui/cases/case-2/index.html"
      },
      {
        "id": "s3",
        "image": "https://pictures-for-portfolio-1465022720.cos.ap-shanghai.myqcloud.com/1.png",
        "title": "Dream Bank",
        "subtitle": "梦屿 ",
        "link": "/ui/cases/case-3/index.html"
      }
    ]
  },
  "home": {
    "featuredEyebrow": "SELECTED WORKS",
    "featuredTitle": "精选案例",
    "featuredDesc": "四个完整项目，包含APP、和web端设计。",
    "introTitle": "设计于我，是在约束中寻找最优解。",
    "introText": "从用户路径与业务目标出发，用原型验证想法，用系统沉淀效率。我相信好的界面是“看不见设计”的——信息自然流动，操作顺理成章。",
    "introCta": "了解更多"
  },
  "worksPage": {
    "title": "全部作品",
    "description": "每一个项目都是一次完整的设计旅程：从问题定义到方案落地。"
  },
  "about": {
    "name": "王颖",
    "role": "UI/UX 设计师 · 交互设计",
    "avatar": "https://pictures-for-portfolio-1465022720.cos.ap-shanghai.myqcloud.com/touxiang.png",
    "bio": [
      "我是一名正在南京航空航天大学读研的 UI/UX 设计师，目前专注于移动端产品体验与设计系统建设。",
      "我曾在B端工业软件公司实习，进行软件设计，擅长在模糊的需求中建立信息架构，也享受把一个按钮的反馈打磨到“刚刚好”的过程。",
      "工作之外，我持续关注UI的美感、交互细节与动效表现，写设计复盘，相信长期主义。"
    ],
    "skills": [
      "交互设计",
      "UI 设计",
      "设计系统",
      "Figma",
      "Sketch",
      "Principle",
      "ProtoPie",
      "用户研究",
      "设计走查",
      "AIGC 辅助设计"
    ],
    "timeline": [
      {
        "id": "t1",
        "period": "2025.7-8 ",
        "title": " UI/UX 设计师",
        "org": "烜翊数智（上海）科技有限公司",
        "description": "辅助进行核心 APP 的体验迭代与设计系统搭建，推动组件化落地。"
      },
      {
        "id": "t2",
        "period": "2025 — 至今",
        "title": "工业设计工程•研究生",
        "org": "南京航空航天大学",
        "description": "进行视觉与交互设计学习和研究。"
      },
      {
        "id": "t3",
        "period": "2021 — 2025",
        "title": "工业设计 · 本科",
        "org": "南京航空航天大学",
        "description": "系统学习版式、色彩与品牌设计，大三起转入交互方向。"
      }
    ]
  },
  "contact": {
    "title": "联系我",
    "description": "无论是工作机会、项目合作，还是单纯想聊聊设计，都欢迎来信。",
    "email": "1640528590@qq.com",
    "wechat": "arctan920929",
    "socials": []
  },
  "projects": [
    {
      "id": "p1",
      "title": "Mood Garden 情绪花园",
      "subtitle": "「每天的情绪，都会在这里长成一株植物。」",
      "category": "APP 设计",
      "year": "2025",
      "tags": [
        "移动端",
        "情绪产品",
        "体验重构"
      ],
      "description": "一款以植物隐喻情绪状态的心理健康 App，帮助用户记录、梳理与疗愈日常情绪。",
      "cover": "https://pictures-for-portfolio-1465022720.cos.ap-shanghai.myqcloud.com/4.png",
      "link": "/ui/cases/case-1/index.html",
      "featured": true
    },
    {
      "id": "p2",
      "title": "WanderMap ",
      "subtitle": "把城市走成一本私藏地图",
      "category": "APP 设计",
      "year": "2024",
      "tags": [
        "城市探索",
        "轻社交",
        "品牌视觉"
      ],
      "description": "面向城市探索者的慢游 App，用路线串联小店、展览与街角风景，把城市走成一本私藏地图。",
      "cover": "https://pictures-for-portfolio-1465022720.cos.ap-shanghai.myqcloud.com/3.png",
      "link": "/ui/cases/case-2/index.html",
      "featured": true
    },
    {
      "id": "p3",
      "title": "梦屿 Dream Bank",
      "subtitle": "一款面向 Z 世代的梦境记录与分析 App",
      "category": "APP 设计",
      "year": "2025",
      "tags": [
        "趣味互动",
        "组件库",
        "Figma",
        "规范文档"
      ],
      "description": "Z 世代的梦境银行，语音存梦 + AI 分析 + 游戏化反馈，让记梦变成有趣的日常仪式。",
      "cover": "https://pictures-for-portfolio-1465022720.cos.ap-shanghai.myqcloud.com/1.png",
      "link": "/ui/cases/case-3/index.html",
      "featured": true
    },
    {
      "id": "p4",
      "title": "择校星 ChoiceStar",
      "subtitle": "输入分数，看见未来",
      "category": "设计系统",
      "year": "2026",
      "tags": [
        "交互动效",
        "功能设计",
        "信息整合"
      ],
      "description": "高考志愿智能决策平台，用数据与算法帮助考生科学、高效地填报志愿。",
      "cover": "https://pictures-for-portfolio-1465022720.cos.ap-shanghai.myqcloud.com/2.png",
      "link": "/ui/cases/case-4/index.html",
      "featured": true
    }
  ]
};
